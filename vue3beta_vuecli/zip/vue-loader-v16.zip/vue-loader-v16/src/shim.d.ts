declare module 'merge-source-map' {
  export default function merge(inMap: any, outMap: any): any
}
